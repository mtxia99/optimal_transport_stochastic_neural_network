function plot_trajectories
data2 = csvread("0" + "0.1" + "0" + "6ttest_traj4d_312.csv");
data1 = csvread("2" + "0.1" + "0" + "6tpred_traj4d_112.csv");


[m, n] = size(data2);
disp(m)
t = 1:1:n;
t = (t-1) * 0.1;
h1 = plot(t, data1, 'color', 'b', 'LineWidth', 1);
hold on;
h2 = plot(t, data2, 'color', 'r', 'Linewidth', 1);
hold on;
[H, h] = legend('Ground truth $y_1(t)$', 'Predicted $\hat{y}_1(t)$',   'Location', 'north', 'interpreter', 'latex', 'Box', 'off');
set(h(3), 'color' ,'r')
set(h(1), 'fontsize', 16)
set(h(2), 'fontsize', 16)
ylabel('$y_1$', 'Interpreter','latex')
xlabel('time', 'Interpreter','latex')
title('(a) $y_1(t)$, $\sigma=0, a=\frac{1}{4}$', 'Interpreter','latex')
set(gca, 'fontsize', 16)
end