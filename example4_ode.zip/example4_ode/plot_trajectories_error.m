function plot_trajectories_error


    function [data1, data2] = error_calculate1(loss_type, i)
        %layer2_feedforward50w24nonlinear_bias2
        filename =  string(i) + "0.1" +string(loss_type) + "6tf_error" + ".csv";
        %disp("layer4_feedforwardw24nonlinear_bias2.csv")
        %disp(filename)
        %filename = "layer4_feedforwardw24nonlinear_bias2.csv";
        disp(filename)
        data1 = csvread(filename);
        filename2 = string(i) + "0.1" + string(loss_type) + "6tw2_error_loss" + ".csv";
        data2 = csvread(filename2);
        
        %disp(var_error)
    end

    
mean_mean = zeros(21, 5);
mean_var = zeros(21, 5);

mean_mean1 = zeros(21, 1);
var_mean1 = zeros(21, 1);
mean_var1 = zeros(21, 1);
var_var1 = zeros(21, 1);

delta = [0, 0.1, 0.2, 0.3, 0.4, 0.5];

for i=1:5
    [m, v] = error_calculate1(0.4, i-1);
    mean_mean(:, i) =  m;
    mean_var(:, i) = v;
end

for i=1:21

    mean_mean1(i) = mean(mean_mean(i, :));
    mean_var1(i) = sqrt(var(mean_mean(i, :)));
    var_mean1(i) = mean(mean_var(i, :));
    var_var1(i) = sqrt(var(mean_var(i, :)));
end


delta = 1:1:20;
delta = delta;
delta = delta * 0.1;

errorbar(delta, mean_mean1(2:21), mean_var1(2:21), 'r', 'LineWidth', 1, 'DisplayName', 'None'); % Use black dotted lines for error bars
hold on;

errorbar(delta, var_mean1(2:21), var_var1(2:21), 'b', 'LineWidth', 1, 'Linestyle','--', 'DisplayName', 'None');
hold on;


legend( 'error in {\boldmath{$g$}}$(${\boldmath{$y$}}$, t,$ {$\hat{\omega}_t$}$)$', 'error in {\boldmath{$y$}}$(${\boldmath{$y$}$_0$}, $t)$', 'Location', 'west', 'interpreter', 'latex', 'Box', 'off')
%title('Plot of $\sin(x)$','Interpreter','latex')
title('(d) errors in {\boldmath{$y$}} and {\boldmath{$g$}}, $a=\frac{1}{4}, \sigma=0$', 'interpreter', 'latex')
xlabel('standard deviation', 'interpreter', 'latex')
set(gca, 'XMinorTick', 'off')
%xticks([0.1, 0.2, 0.3, 0.4]);  % Set ticks at 0, π/2, π, 3π/2, and 2π
%xticklabels({0.1, 0.2, 0.3, 0.4}); 

ylabel('error', 'Interpreter','latex')
set(gca, 'fontsize', 16)
set(gca, 'YScale', 'log');
xlim([0.1, 2])
%ylim([0.03, 0.23])
end