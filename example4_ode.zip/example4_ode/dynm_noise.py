# -*- coding: utf-8 -*-
"""
Created on Thu May 16 23:14:52 2024

@author: 12147
"""

# -*- coding: utf-8 -*-
"""
Created on Mon Apr 29 22:26:18 2024

@author: 12147
"""

# -*- coding: utf-8 -*-
"""
Created on Sat Apr 27 11:53:05 2024

@author: 12147
"""

# -*- coding: utf-8 -*-
"""
Created on Fri Mar 22 15:33:21 2024

@author: 12147
"""

# -*- coding: utf-8 -*-
"""
Created on Mon Mar 18 15:05:58 2024

@author: 12147
"""

import numpy as np
import torch 
import torchbnn as bnn
import pdb
from tqdm import tqdm
import torch.nn as nn
import pdb
import csv
from torchdiffeq import odeint
torch.set_num_threads(1)
device = torch.device("cpu")
torch.autograd.set_detect_anomaly(True)
class BayesianLinear(nn.Module):
    def __init__(self, in_features, out_features):
        super(BayesianLinear, self).__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.weight_mu = nn.Parameter(0.02*torch.randn(out_features, in_features))
        self.weight_logstd = nn.Parameter(0.02*torch.randn(out_features, out_features))
        self.bias_mu = nn.Parameter(0.02*torch.randn(out_features))
        self.bias_logstd = nn.Parameter(0.02*torch.randn(out_features, out_features))

    def forward(self, x):
        # Sample weights using the reparameterization trick
        rand_shape = torch.zeros(x.shape[0], self.in_features, self.out_features)
        bias_shape = torch.zeros(x.shape[0], self.out_features)
        epsilon_weight = torch.randn_like(x)
        epsilon_bias = torch.randn_like(x)
        sampled_weight = self.weight_mu #+ self.weight_logstd * epsilon_weight
        sampled_bias = self.bias_mu #+ torch.matmul(torch.randn_like(bias_shape), self.bias_logstd)
        #pdb.set_trace()
        z = torch.matmul(x, sampled_weight.transpose(0, 1)) + sampled_bias
        z += torch.matmul(x.unsqueeze(1), torch.matmul(torch.randn_like(rand_shape), self.weight_logstd)).squeeze(1)
        #for i in range(x.shape[0]):
        #    z[i, :] += torch.matmul(x[i, :], torch.matmul(torch.randn_like(rand_shape), self.weight_logstd))
            
        return z#torch.matmul(x, sampled_weight.t()) + x * torch.matmul(epsilon_weight, self.weight_logstd)+ sampled_bias

class ODE(nn.Module):

    def __init__(self, latent_dim=4, nhidden=200):
        super(ODE, self).__init__()
        #self.elu = nn.ELU(inplace=True)
        self.Relu = nn.ELU(inplace=True)
        self.fc1 = BayesianLinear(latent_dim, nhidden)
        self.fc2 = BayesianLinear(nhidden, nhidden)
        #self.fc3 = nn.Linear(nhidden, nhidden)
        #self.fc4 = nn.Linear(nhidden, nhidden)
        self.fc9 = BayesianLinear(nhidden, latent_dim)
        self.nfe = 0

    def forward(self, t, x):
        self.nfe += 1
        #out = -0.1 * x + torch.randn_like(x) * 0.2
        out = self.fc1(x)
        out = self.Relu(out)
        out = self.fc2(out)
        out = self.Relu(out)
        out = self.fc9(out)
        return out

import random


class ODE_truth(nn.Module):

    def __init__(self, latent_dim=4, nhidden=20):
        super(ODE_truth, self).__init__()
        #self.elu = nn.ELU(inplace=True)
        self.Relu = nn.ELU(inplace=True)
        self.fc1 = nn.Linear(latent_dim, nhidden)
        #self.fc2 = nn.Linear(nhidden, nhidden)
        #self.fc3 = nn.Linear(nhidden, nhidden)
        #self.fc4 = nn.Linear(nhidden, nhidden)
        self.fc9 = nn.Linear(nhidden, latent_dim)
        self.nfe = 0

    def forward(self, t, x):
        #self.nfe += 1
        out = torch.zeros(x.shape[0], x.shape[1])
        for i in range(x.shape[0]):
            xi = (random.random() -0.5) / 2 * a / 10
            out[i, 0] = (0.05 + xi) * x[i, 0] + 0.05 * x[i, 2] - (1 - xi**2) * x[i, 1]
            out[i, 1] = (1 - xi**2) * x[i, 0] + 0.05 * x[i, 3]
            out[i, 2] = (-0.05 + xi) * x[i, 2] - (1-xi**2) * x[i, 3]
            out[i, 3] = (1-xi**2) * x[i, 2]
        #out = -0.1 * x + torch.sin(x) + torch.randn_like(x) * 0.5
        #out = self.fc1(x)
        #out = self.Relu(out)
        #out = self.fc9(out)
        return out
    

    
n = 4




import ot     
def distance(P, Q):
    cost_matrix = ot.dist(P, Q,metric='sqeuclidean')
    return cost_matrix

batch_sample = 10

def norm(x, y, delta = 1e-4):
    if torch.sqrt(torch.sum(torch.square(x-y))) <= delta:
        return True
    
    return False
    
def neighbors(sample, samples):
    num = 0
    neighborhood = []
    for i in range(samples.shape[0]):
        if norm(sample, samples[i]):
            neighborhood.append(i)
            num += 1
        
    return neighborhood, num


def w2_decoupled_loss(X, y, y_pred):
    #batch_size = int(y.shape[0] / batch_sample)
    #print(y.shape[0])
    #print(batch_size, y.shape, y_pred.shape)
    #pdb.set_trace()
    #t_size = y.shape[0]
    loss = 0
    #weights = torch.tensor([1/batch_size for _ in range(batch_size)]).to(device)
    
    for i in range(y.shape[0]):
        neighborhood, num = neighbors(X[i], X)
        weights = torch.tensor([1/num for _ in range(num)]).to(device)
        loss += ot.emd2(weights, weights, distance(y[neighborhood], y_pred[neighborhood])) * num / y.shape[0]
        
    
    return loss


def w2_decoupled0(y, y_pred):
    batch_size = y.shape[1]
    state_size = y.shape[2]
    t_size = y.shape[0]
    loss = 0
    for i in range(1, t_size):
        weights = torch.tensor([1/batch_size for _ in range(batch_size)]).to(device)
        
        loss += ot.emd2(weights, weights, distance(y[i, :, :], y_pred[i, :, :]))
            
    return loss

def w2_decoupled(y, y_pred):
    global neighborhoods, nums
    batch_size = y.shape[1]
    state_size = y.shape[2]
    t_size = y.shape[0]
    loss = 0
    for i in range(1, t_size):
        for j in range(1, y.shape[1]):
            neighborhood, num = neighborhoods[j], nums[j]
            weights = torch.tensor([1/num for _ in range(num)]).to(device)
            
            loss += ot.emd2(weights, weights, distance(y[i, neighborhood, :], y_pred[i, neighborhood, :]))
        
        #loss /= y.shape[1]
    return loss / y.shape[0] / y.shape[1]

def w2_decoupled_original(y, y_pred):
    batch_size = y.shape[0]
    state_size = y.shape[1]
    weights = torch.tensor([1/batch_size for _ in range(batch_size)]).to(device)
        
    loss = ot.emd2(weights, weights, distance(y[ :, :], y_pred[ :, :]))
            
    return loss

def total_error1(sde_truth, sde, ys, ys_pred, ts, i0):
    sample_size = 25
    w2f_list = []
    t_size = ys.shape[0]
    for i in range(t_size):
        summ = 0
        summ_ref = 0
        for j in range(ys.shape[1]):
            ys_test = torch.zeros(sample_size, ys.shape[2])
            for s in range(sample_size):
                ys_test[s, :] = ys[i, j, :]
            #ys_test = ys[i, j, :].expand(sample_size, 1)
            
            #pdb.set_trace()
            pred = sde.forward(ts[i], ys_test)
            truth = sde_truth.forward(ts[i], ys_test)
            summ += w2_decoupled_original( pred, truth).item()
        #summ += torch.sum(torch.abs( sde.f(ts[i], ys[i]) - sde_truth.f(ts[i], ys[i])))
            summ_ref += w2_decoupled_original(pred*0, truth).item()#torch.sum(torch.abs(sde_truth.forward(ts[i], ys[i])))# + torch.sum(torch.abs(sde.f(ts[i], ys_truth[i])))
        
        w2f_list.append(float(summ/summ_ref))
    
    t_size = ys.shape[0]
    w2_list = []
    for i in range(t_size):
        summ = 0
        summ_ref = 0
        summ += w2_decoupled_original(ys_pred[i,:, :], ys[i, :, :]).item()
        summ_ref += w2_decoupled_original(ys_pred[i,:, :]*0, ys[i, :, :]).item()
        w2_list.append(float(summ / summ_ref))
        
    print(sum(w2_list) / t_size, sum(w2f_list) / t_size)
    return w2f_list, w2_list

def test_traj(sde_truth, sde, ys, ts, i0):
    sample_size = 50
    summ = 0
    summ_ref = 0
    t_size = ys.shape[0]
    pred_traj = [[0 for j in range(sample_size)] for i in range(t_size)]
    truth_traj = [[0 for j in range(sample_size)] for i in range(t_size)]
    for i in range(t_size):
        #for j in range(ys.shape[1]):
        ys_test = torch.zeros(sample_size, ys.shape[2])
        for s in range(sample_size):
            ys_test[s, :] = ys[i, s, :]
        pred = sde.forward(ts[i], ys_test)
        truth = sde_truth.forward(ts[i], ys_test)
        for j in range(sample_size):
            pred_traj[i][j] = float(pred[j, 0])
            truth_traj[i][j] = float(truth[j, 0])
            #summ += w2_decoupled_original( pred, truth)
        #summ += torch.sum(torch.abs( sde.f(ts[i], ys[i]) - sde_truth.f(ts[i], ys[i])))
            #summ_ref += w2_decoupled_original(pred*0, truth)#torch.sum(torch.abs(sde_truth.forward(ts[i], ys[i])))# + torch.sum(torch.abs(sde.f(ts[i], ys_truth[i])))
                
        
    
    return pred_traj, truth_traj

from time import time

ll = 21
dt = 0.1
t_list = torch.tensor([dt*(i) for i in range(ll)])
batch_size = 200
y0 = torch.zeros(batch_size, 4)

def generate_data(num_samples, sigma, y0):
    for i in range(num_samples):
        y0[i, 0] = 1 + torch.randn(1) * sigma
        y0[i, 1] = 1 + torch.randn(1) * sigma
        y0[i, 2] = 1 + torch.randn(1) * sigma
        y0[i, 3] = 1 + torch.randn(1) * sigma
        
    return y0

#y0 = torch.tensor([[1.,0.,1.,0.] for i in range(batch_size)])

def norm(x, y, delta = 0.05):
    if torch.sqrt(torch.sum(torch.square(x-y))) <= delta:
        return True
    
    return False
    
def neighbors(sample, samples, delta):
    num = 0
    neighborhood = []
    for i in range(samples.shape[0]):
        if norm(sample, samples[i], delta):
            neighborhood.append(i)
            num += 1
        
    return neighborhood, num

    

def csv_process(filename):
            
    data = []
    with open(filename, 'r') as file:
        # Create a CSV reader object
        csv_reader = csv.reader(file)
                
                # Iterate over each row in the CSV file
        for row in csv_reader:
            temp = []
            for j in row:
                temp.append(float(j))
                    
                    # Append each row to the data list
            data.append(temp)
                    
    return torch.tensor(data).transpose(0, 1)
    
    #neighborhoods_t = []
    #nums_t = []
    #for i in range(y0.shape[0]):
    #    neighborhood, num = neighbors(X_test[i], X_test, delta)
    #    nums_t.append(num)
    #    neighborhoods_t.append(neighborhood)
import pandas as pd
def run_experiment(i, sigma, delta = 0.1, mode='g'):
    global batch_size, neighborhoods, neighborhoods_t, nums, nums_t, a
    import pandas as pd
    
    ODE_ground = ODE_truth(n, 100)
    ODE_approx = ODE(n, 100)
    #ODE_approx.load_state_dict(torch.load('00.104DODE.pkl'))
    #criterion = torch.nn.MSELoss(reduction='sum')
    optimizer = torch.optim.Adam(ODE_approx.parameters(), lr=0.01)
    #optimizer.zero_grad()
    num_samples = 200
    if mode == 'g':
        y0 = torch.tensor([[1.,1.,1.,1.] for i in range(batch_size)])
        y0 = generate_data(batch_size, sigma, y0)
        #print(y0)
        ys = odeint(ODE_ground, y0, t_list, method = 'rk4').to(device) 
        #print(ys)
        y0_t = torch.tensor([[1.,1.,1.,1.] for i in range(batch_size)])
        y0_t = generate_data(batch_size, sigma, y0)
        ys_t = odeint(ODE_ground, y0_t, t_list, method = 'rk4').to(device) 
        loss_data = pd.DataFrame(data = [[float(ys_t[i, j, 0]) for i in range(ll)] for j in range(batch_size)])
        loss_data.to_csv(str(i) + str(delta) + str(sigma) +'6ttest_traj4d_1_a'+ str(a) +'.csv', header=False, index = False)
        
        loss_data = pd.DataFrame(data = [[float(ys_t[i, j, 1]) for i in range(ll)] for j in range(batch_size)])
        loss_data.to_csv(str(i) + str(delta) + str(sigma) +'6ttest_traj4d_2_a'+ str(a) +'.csv', header=False, index = False)
        
        loss_data = pd.DataFrame(data = [[float(ys_t[i, j, 2]) for i in range(ll)] for j in range(batch_size)])
        loss_data.to_csv(str(i) + str(delta) + str(sigma) +'6ttest_traj4d_3_a'+ str(a) +'.csv', header=False, index = False)
        
        loss_data = pd.DataFrame(data = [[float(ys_t[i, j, 3]) for i in range(ll)] for j in range(batch_size)])
        loss_data.to_csv(str(i) + str(delta) + str(sigma) +'6ttest_traj4d_4_a'+ str(a) +'.csv', header=False, index = False)
        
        
        loss_data = pd.DataFrame(data = [[float(ys[i, j, 0]) for i in range(ll)] for j in range(batch_size)])
        loss_data.to_csv(str(i) + str(delta) + str(sigma) +'6ttrain_traj4d_1_a' + str(a) + '.csv', header=False, index = False)
        
        loss_data = pd.DataFrame(data = [[float(ys[i, j, 1]) for i in range(ll)] for j in range(batch_size)])
        loss_data.to_csv(str(i) + str(delta) + str(sigma) +'6ttrain_traj4d_2_a' + str(a) + '.csv', header=False, index = False)
        
        loss_data = pd.DataFrame(data = [[float(ys[i, j, 2]) for i in range(ll)] for j in range(batch_size)])
        loss_data.to_csv(str(i) + str(delta) + str(sigma) +'6ttrain_traj4d_3_a' + str(a) + '.csv', header=False, index = False)
        
        loss_data = pd.DataFrame(data = [[float(ys[i, j, 3]) for i in range(ll)] for j in range(batch_size)])
        loss_data.to_csv(str(i) + str(delta) + str(sigma) +'6ttrain_traj4d_4_a' + str(a) + '.csv', header=False, index = False)
        
    else:
        ys = torch.zeros(ll, batch_size, 4)
        ys_t = torch.zeros(ll, batch_size, 4)
        ys[:, :, 0] = csv_process(str(i) + str(delta) + str(sigma) +'6ttrain_traj4d_1_a' + str(a) + '.csv')
        ys[:, :, 1] = csv_process(str(i) + str(delta) + str(sigma) +'6ttrain_traj4d_2_a' + str(a) + '.csv')
        ys[:, :, 2] = csv_process(str(i) + str(delta) + str(sigma) +'6ttrain_traj4d_3_a' + str(a) + '.csv')
        ys[:, :, 3] = csv_process(str(i) + str(delta) + str(sigma) +'6ttrain_traj4d_4_a' + str(a) + '.csv')
        y0 = ys[0, :, :]
        ys_t[:, :, 0] = csv_process(str(i) + str(delta) + str(sigma) +'6ttest_traj4d_1_a' + str(a) + '.csv')
        ys_t[:, :, 1] = csv_process(str(i) + str(delta) + str(sigma) +'6ttest_traj4d_2_a' + str(a) + '.csv')
        ys_t[:, :, 2] = csv_process(str(i) + str(delta) + str(sigma) +'6ttest_traj4d_3_a' + str(a) + '.csv')
        ys_t[:, :, 3] = csv_process(str(i) + str(delta) + str(sigma) +'6ttest_traj4d_4_a' + str(a) + '.csv')
        y0_t = ys_t[0, :, :]
        
    neighborhoods = []
    nums = []
    delta = 0.1
    for i0 in range(y0.shape[0]):
        neighborhood, num = neighbors(y0[i0], y0, delta)
        nums.append(num)
        neighborhoods.append(neighborhood)
    
    #print(neighborhoods)
    #pdb.set_trace()
    neighborhoods_t = []
    nums_t = []
    for i0 in range(y0.shape[0]):
        neighborhood, num = neighbors(y0[i0], y0, delta)
        nums_t.append(num)
        neighborhoods_t.append(neighborhood)
    
    truth = odeint(ODE_ground, y0, t_list, method = 'rk4')
    error_f = []
    loss_list = []
    epoch = 500
    print('start')
    ttime = time()
    for i0 in tqdm(range(epoch)):
                #print(i)
        optimizer.zero_grad()
        ys = odeint(ODE_approx, y0, t_list, method = 'rk4').to(device) 
        loss =  w2_decoupled(ys, truth)
        
        loss.backward()
        optimizer.step()
        if i0 % 10 == 0:
            print(i0, loss.item())
            #f_error= total_error1(ODE_truth, ODE_approx, ys, t_list, i0)
            #error_f.append(f_error)
            #print(time() - ttime)
            
                    
            loss_list.append(loss.item())
    
    
    #ODE_approx.load_state_dict(torch.load(str(i) + str(delta) + str(sigma) + '4DODEmodel' +'.pkl'))
    ys_test_pred = odeint(ODE_approx, y0_t, t_list, method='rk4')
    #ttime = time()
    pred_traj0, truth_traj0 = total_error1(ODE_ground, ODE_approx, ys_t, ys_test_pred, t_list, 0)
    #pred_traj1, truth_traj1 = test_traj(ODE_truth, ODE_approx, ys, t_list, i0, 1)
    #pred_traj2, truth_traj2 = test_traj(ODE_truth, ODE_approx, ys, t_list, i0, 2)
    #pred_traj3, truth_traj3 = test_traj(ODE_truth, ODE_approx, ys, t_list, i0, 3)
    import pandas as pd 
    torch.save(ODE_approx.state_dict(), str(i) + str(delta) + str(sigma) + '6t4DODEmodel_a' + str(a)  +'.pkl')
    #ODE_approx.load_state_dict(torch.load('1dnonlinear_model_multilayer2.pkl'))
    
    loss_data = pd.DataFrame(data = [[float(ys_test_pred[i0, j, 0]) for i0 in range(ll)] for j in range(batch_size)])
    loss_data.to_csv(str(i) + str(delta) + str(sigma) +'6tpred_traj4d_1_a' + str(a) + '.csv', header=False, index = False)
    
    loss_data = pd.DataFrame(data = [[float(ys_test_pred[i0, j, 1]) for i0 in range(ll)] for j in range(batch_size)])
    loss_data.to_csv(str(i) + str(delta) + str(sigma) +'6tpred_traj4d_2_a' + str(a) + '.csv', header=False, index = False)
    
    loss_data = pd.DataFrame(data = [[float(ys_test_pred[i0, j, 2]) for i0 in range(ll)] for j in range(batch_size)])
    loss_data.to_csv(str(i) + str(delta) + str(sigma) +'6tpred_traj4d_3_a' + str(a) + '.csv', header=False, index = False)
    
    loss_data = pd.DataFrame(data = [[float(ys_test_pred[i0, j, 3]) for i0 in range(ll)] for j in range(batch_size)])
    loss_data.to_csv(str(i) + str(delta) + str(sigma) +'6tpred_traj4d_4_a' + str(a) + '.csv', header=False, index = False)
    
    loss_data = pd.DataFrame(data = pred_traj0)
    loss_data.to_csv(str(i) + str(delta) + str(sigma) +'6tf_error_a' + str(a) + '.csv', header=False, index = False)
    
    loss_data = pd.DataFrame(data = truth_traj0)
    loss_data.to_csv(str(i) + str(delta) + str(sigma) +'6tw2_error_loss_a' + str(a) + '.csv', header=False, index = False)
    
    #loss_data = pd.DataFrame(data = [[float(ys[i, j, 0]) for i in range(truth.shape[0])] for j in range(truth.shape[1])])
    #loss_data.to_csv(str(i) + str(delta) + str(sigma) +'pred4d.csv', header=False, index = False)
    return time() - ttime

times = []
sigma = 0
a = 16
for i in range(5):
    times.append(run_experiment(i, sigma, 0.1, 'g'))

loss_data = pd.DataFrame(data = times)
loss_data.to_csv( str(sigma) + '6tpred4d_1_a' + str(a) + '.csv', header=False, index = False)
