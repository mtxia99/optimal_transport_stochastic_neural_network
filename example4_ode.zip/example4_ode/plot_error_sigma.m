function plot_error_sigma


    function [data1, data2] = error_calculate1(loss_type, i)
        %layer2_feedforward50w24nonlinear_bias2
        filename =  string(i) + "0.1" +string(loss_type) + "6tf_error" + ".csv";
        %disp("layer4_feedforwardw24nonlinear_bias2.csv")
        %disp(filename)
        %filename = "layer4_feedforwardw24nonlinear_bias2.csv";
        disp(filename)
        data1 = csvread(filename);
        filename2 = string(i) + "0.1" + string(loss_type) + "6tw2_error_loss" + ".csv";
        data2 = csvread(filename2);
        
        %disp(var_error)
    end

    
mean_mean = zeros(21, 5);
mean_var = zeros(21, 5);

mean_mean1 = zeros(6, 5);
var_mean1 = zeros(6, 5);
mean_var1 = zeros(6, 5);
var_var1 = zeros(6, 5);

delta = [0, 0.1, 0.2, 0.3, 0.4, 0.5];

for j=1:6

    for i=1:5
        [m, v] = error_calculate1(delta(j), i-1);
        mean_mean(j, i) =  mean(m);
        mean_var(j, i) = mean(v);
    end
end
disp(mean_mean)

f_error = zeros(6, 1);
f_var = zeros(6, 1);
w2_error = zeros(6, 1);
w2_var = zeros(6, 1);

for j=1:6
    f_error(j, 1) = mean(mean_mean(j, :));
    f_var(j, 1) = sqrt(var(mean_mean(j, :)));
    w2_error(j, 1) = mean(mean_var(j, :));
    w2_var(j, 1) = sqrt(var(mean_var(j, :)));
end


errorbar(delta, f_error, f_var, 'r', 'LineWidth', 1, 'DisplayName', 'None'); % Use black dotted lines for error bars
hold on;

errorbar(delta, w2_error, w2_var, 'b', 'LineWidth', 1, 'Linestyle','--', 'DisplayName', 'None');
hold on;


legend( 'error in {\boldmath{$g$}}$(${\boldmath{$y$}}$, t,$ {$\hat{\omega}_t$}$)$', 'error in {\boldmath{$y$}}$(${\boldmath{$y$}$_0$}, $t)$', 'Location', 'west', 'interpreter', 'latex', 'Box', 'off')
%title('Plot of $\sin(x)$','Interpreter','latex')
title('(e) time-averaged errors in {\boldmath{$y$}} and {\boldmath{$g$}}', 'interpreter', 'latex')
xlabel('$\sigma$', 'interpreter', 'latex')
set(gca, 'XMinorTick', 'off')
%xticks([0.1, 0.2, 0.3, 0.4]);  % Set ticks at 0, π/2, π, 3π/2, and 2π
%xticklabels({0.1, 0.2, 0.3, 0.4}); 

ylabel('error', 'Interpreter','latex')
set(gca, 'fontsize', 16)
%set(gca, 'YScale', 'log');
xlim([0, 0.5])
%ylim([0.03, 0.23])
end