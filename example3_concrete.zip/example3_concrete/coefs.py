# -*- coding: utf-8 -*-
"""
Created on Tue Jun  4 10:42:52 2024

@author: 12147
"""

# -*- coding: utf-8 -*-
"""
Created on Mon Apr 22 17:25:16 2024

@author: 12147
"""

import numpy as np
import pandas as pd
import torch
from sklearn.linear_model import LinearRegression
model = LinearRegression()
import csv

def read_line(lst):
    
    result = []
    for i in lst:
        result.append(float(i))
    
    return result

data1 = []

with open('concrete.csv', mode='r') as file:
    csvFile = csv.reader(file)
    for lines in csvFile:
        data1.append(read_line(lines))
        #print(lines)
        




    
    #print(list(line))  # strip() removes leading and trailing whitespace

data1 = torch.tensor(data1)
mean = []
var = []
for i in range(8):
    mean.append(torch.mean(data1[:, i]))
    var.append(torch.var(data1[:, i]))

for i in range(8):
    if i != 15:
        
        data1[:, i] = (data1[:, i] - mean[i]) / torch.sqrt(var[i])
    
#independent = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,16]
independent = [0,2,3,4,5,6]
model.fit(np.array(data1[:, independent]), np.array(data1[:, -1]))
slope = model.coef_
print(slope)