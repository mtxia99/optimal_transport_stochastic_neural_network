function plot_error
    
    function [mean_error, var_error] = error_calculate2(loss_type, i)
        %layer2_feedforward50w24nonlinear_bias2
        if loss_type ==  string(0.1)

            filename =  "shorttest_MSE_concrete_new_data"  +string(loss_type) + string(i) + ".csv";
            filename2 = "shorttest_MSE_concrete_new_data_pred"  +string(loss_type) + string(i) + ".csv";
        else
            filename =  "shorttest_MSE_concrete_new_data"  +string(loss_type) + string(i) + ".csv";
            filename2 = "shorttest_MSE_concrete_new_data_pred"  +string(loss_type) + string(i) + ".csv";
        end
        %disp("layer4_feedforwardw24nonlinear_bias2.csv")
        disp(filename)
        %filename = "layer4_feedforwardw24nonlinear_bias2.csv";
        data1 = csvread(filename);
        
        data2 = csvread(filename2);
        mean_list = 0;
        var_list = 0;
        mean_error = 0;
        var_error = 0;
        [m, n] = size(data2);
        function y = nonzero(x)
            y = n;
            for r=1:n
                if x(r) == 0
                    y = r;
                    
                    break
                end
            end
        end

        for i=1:m
            n1 = nonzero(data1(i, :));
            mean_list = mean_list + abs(mean(data2(i, 1:n1)));
            mean_error = mean_error + abs(mean(data1(i, 1:n1)) - mean(data2(i, 1:n1)));
            var_list = var_list + sqrt(var(data2(i, 1:n1)));
            var_error = var_error + abs(sqrt(var(data1(i, 1:n1))) - sqrt(var(data2(i, 1:n1))));
        end
    
        mean_error = mean_error/mean_list;
        var_error = var_error / var_list;
        %disp(var_error)
    end

    function [mean_error, var_error] = error_calculate1(loss_type, i)
        %layer2_feedforward50w24nonlinear_bias2
        if loss_type ==  string(0.1)

            filename =  "shorttest_MSE_concrete_new_data"  +string(loss_type) + string(i) + "5015.csv";
            filename2 = "shorttest_MSE_concrete_new_data_pred"  +string(loss_type) + string(i) + "5015.csv";
        else
            filename =  "shorttest_MSE_concrete_new_data"  +string(loss_type) + string(i) + "5015.csv";
            filename2 = "shorttest_MSE_concrete_new_data_pred"  +string(loss_type) + string(i) + "5015.csv";
        end
        %disp("layer4_feedforwardw24nonlinear_bias2.csv")
        disp(filename)
        %filename = "layer4_feedforwardw24nonlinear_bias2.csv";
        data1 = csvread(filename);
        
        data2 = csvread(filename2);
        mean_list = 0;
        var_list = 0;
        mean_error = 0;
        var_error = 0;
        [m, n] = size(data2);
        function y = nonzero(x)
            y = n;
            for r=1:n
                if x(r) == 0
                    y = r;
                    
                    break
                end
            end
        end

        for i=1:m
            n1 = nonzero(data1(i, :));
            mean_list = mean_list + abs(mean(data2(i, 1:n1)));
            mean_error = mean_error + abs(mean(data1(i, 1:n1)) - mean(data2(i, 1:n1)));
            var_list = var_list + sqrt(var(data2(i, 1:n1)));
            var_error = var_error + abs(sqrt(var(data1(i, 1:n1))) - sqrt(var(data2(i, 1:n1))));
        end
    
        mean_error = mean_error/mean_list;
        var_error = var_error / var_list;
        %disp(var_error)
    end

    function [mean_error, var_error] = error_calculate(loss_type, i)
        %layer2_feedforward50w24nonlinear_bias2
        if or(loss_type == string(0.4), loss_type == string(0.2))

            filename =  "shorttest_w2_concrete_new_data"  +string(loss_type) + string(i) + "505.csv";
            filename2 = "shorttest_w2_concrete_new_data_pred"  +string(loss_type) + string(i) + "505.csv";
        else
            filename =  "shorttest_w2_concrete_new_data"  +string(loss_type) + string(i) + "505.csv";
            filename2 = "shorttest_w2_concrete_new_data_pred"  +string(loss_type) + string(i) + "505.csv";
        end

        %disp("layer4_feedforwardw24nonlinear_bias2.csv")
        %disp(filename)
        %filename = "layer4_feedforwardw24nonlinear_bias2.csv";
        data1 = csvread(filename);
        
        data2 = csvread(filename2);
        mean_list = 0;
        var_list = 0;
        mean_error = 0;
        var_error = 0;
        [m, n] = size(data2);
        function y = nonzero(x)
            y = n;
            for r=1:n
                if x(r) == 0
                    y = r;
                    
                    break
                end
            end
        end

        for i=1:m
            n1 = nonzero(data1(i, :));
            mean_list = mean_list + abs(mean(data2(i, 1:n1)));
            mean_error = mean_error + abs(mean(data1(i, 1:n1)) - mean(data2(i, 1:n1)));
            var_list = var_list + sqrt(var(data2(i, 1:n1)));
            var_error = var_error + abs(sqrt(var(data1(i, 1:n1))) - sqrt(var(data2(i, 1:n1))));
        end
    
        mean_error = mean_error/mean_list;
        var_error = var_error / var_list;
        %disp(var_error)
    end

    function [mean_error, var_error] = error_calculate3(loss_type, i)
        %layer2_feedforward50w24nonlinear_bias2
        if or(loss_type == string(0.4), loss_type == string(0.2))

            filename =  "shorttest_MMD_concrete_new_data"  +string(loss_type) + string(i) + "505.csv";
            filename2 = "shorttest_MMD_concrete_new_data_pred"  +string(loss_type) + string(i) + "505.csv";
        else
            filename =  "shorttest_MMD_concrete_new_data"  +string(loss_type) + string(i) + "505.csv";
            filename2 = "shorttest_MMD_concrete_new_data_pred"  +string(loss_type) + string(i) + "505.csv";
        end

        %disp("layer4_feedforwardw24nonlinear_bias2.csv")
        %disp(filename)
        %filename = "layer4_feedforwardw24nonlinear_bias2.csv";
        data1 = csvread(filename);
        
        data2 = csvread(filename2);
        mean_list = 0;
        var_list = 0;
        mean_error = 0;
        var_error = 0;
        [m, n] = size(data2);
        function y = nonzero(x)
            y = n;
            for r=1:n
                if x(r) == 0
                    y = r;
                    
                    break
                end
            end
        end

        for i=1:m
            n1 = nonzero(data1(i, :));
            mean_list = mean_list + abs(mean(data2(i, 1:n1)));
            mean_error = mean_error + abs(mean(data1(i, 1:n1)) - mean(data2(i, 1:n1)));
            var_list = var_list + sqrt(var(data2(i, 1:n1)));
            var_error = var_error + abs(sqrt(var(data1(i, 1:n1))) - sqrt(var(data2(i, 1:n1))));
        end
    
        mean_error = mean_error/mean_list;
        var_error = var_error / var_list;
        %disp(var_error)
    end

mean_mean_m = zeros(5, 1);
var_mean_m = zeros(5, 1);
mean_var_m = zeros(5, 1);
var_var_m = zeros(5, 1);

delta = [0.025, 0.05, 0.1, 0.2, 0.3];
for j=1:5
    mean_t = zeros(5, 1);
    var_t = zeros(5, 1);
    for i=1:5
        [m1, v] = error_calculate3(string(delta(j)), i-1);
        mean_t(i) =  m1;
        var_t(i) = v;
    end
    mean_mean_m(j) = mean(mean_t);
    var_mean_m(j) = mean(var_t);

    mean_var_m(j) = sqrt(var(mean_t));
    var_var_m(j) = sqrt(var(var_t));
end

mean_mean = zeros(5, 1);
var_mean = zeros(5, 1);
mean_var = zeros(5, 1);
var_var = zeros(5, 1);

delta = [0.025, 0.05, 0.1, 0.2, 0.3];
for j=1:5
    mean_t = zeros(5, 1);
    var_t = zeros(5, 1);
    for i=1:5
        [m1, v] = error_calculate(string(delta(j)), i-1);
        mean_t(i) =  m1;
        var_t(i) = v;
    end
    mean_mean(j) = mean(mean_t);
    var_mean(j) = mean(var_t);

    mean_var(j) = sqrt(var(mean_t));
    var_var(j) = sqrt(var(var_t));
end

mean_meant = zeros(5, 1);
var_meant = zeros(5, 1);
mean_vart = zeros(5, 1);
var_vart = zeros(5, 1);

for j=1:5
    mean_t = zeros(5, 1);
    var_t = zeros(5, 1);
    for i=1:5
        %[m, v] = error_calculate1(string(delta(j)), i-1);
        [m, v] = error_calculate1(string(0.2), i-1);
        mean_t(i) =  m;
        var_t(i) = v;
    end
    mean_meant(j) = mean(mean_t);
    var_meant(j) = mean(var_t);

    mean_vart(j) = sqrt(var(mean_t));
    var_vart(j) = sqrt(var(var_t));
end

plot(delta, mean_mean, 'r', 'Marker', 'o',  'LineWidth', 1)
hold on;

plot(delta, var_mean, 'r', 'Marker','o',  'Linestyle','--', 'LineWidth', 1);
hold on;

plot(delta, mean_meant, 'b', 'Marker', '*', 'LineWidth', 1)
hold on;

plot(delta, var_meant, 'b', 'Marker','*', 'Linestyle','--', 'LineWidth', 1);
hold on;

plot(delta, mean_mean_m, 'g', 'Marker', '+', 'LineWidth', 1)
hold on;

plot(delta, var_mean_m, 'g', 'Marker','+', 'Linestyle','--', 'LineWidth', 1);
hold on;

errorbar(delta, mean_mean, mean_var, 'r', 'LineWidth', 1, 'DisplayName', 'None'); % Use black dotted lines for error bars
hold on;

errorbar(delta, var_mean, var_var, 'r', 'LineWidth', 1, 'Linestyle','--', 'DisplayName', 'None');
hold on;

errorbar(delta, mean_meant, mean_vart, 'b', 'LineWidth', 1,  'DisplayName', 'None'); % Use black dotted lines for error bars
hold on;

errorbar(delta, var_meant, var_vart, 'b', 'LineWidth', 1,'Linestyle','--', 'DisplayName', 'None');

errorbar(delta, mean_mean_m, mean_var_m, 'g', 'LineWidth', 1,  'DisplayName', 'None'); % Use black dotted lines for error bars
hold on;

errorbar(delta, var_mean_m, var_var_m, 'g', 'LineWidth', 1,'Linestyle','--', 'DisplayName', 'None');

disp(var_meant)
legend( 'error in E$[\hat{y}]$, local squared $W_2$', 'error in SD$[y]$, local squared $W_2$', 'error in E$[\hat{y}]$, MSE', 'error in SD$[y]$, MSE',  'error in E$[\hat{y}]$, local MMD', 'error in SD$[y]$, local MMD', 'Location', 'northwest', 'interpreter', 'latex', 'Box', 'off')
%title('Plot of $\sin(x)$','Interpreter','latex')
title('(c) errors w.r.t. the size of neighborhood', 'interpreter', 'latex')
xlabel('$\delta$', 'interpreter', 'latex')
set(gca, 'XMinorTick', 'off')
xticks([0.025,0.05, 0.1, 0.2, 0.3]);  % Set ticks at 0, π/2, π, 3π/2, and 2π
xticklabels({0.025, 0.05, 0.1, 0.2, 0.3}); 
set(gca, 'Xscale', 'log')
set(gca, 'Xminortick', 'off')
ylabel('error', 'Interpreter','latex')
set(gca, 'fontsize', 16)
xlim([0.025, 0.3])
ylim([0.1, 1.2])
end