# -*- coding: utf-8 -*-
"""
Created on Tue Jun  4 10:38:48 2024

@author: 12147
"""

# -*- coding: utf-8 -*-
"""
Created on Sun May  5 16:09:42 2024

@author: 12147
"""

# -*- coding: utf-8 -*-
"""
Created on Sun May  5 02:35:15 2024

@author: 12147
"""

# -*- coding: utf-8 -*-
"""
Created on Sat Apr 20 18:09:48 2024

@author: 12147
"""

# -*- coding: utf-8 -*-
"""
Created on Fri Mar 22 16:10:44 2024

@author: 12147
"""

# -*- coding: utf-8 -*-
"""
Created on Mon Jan 22 21:29:06 2024

@author: 12147
"""

# -*- coding: utf-8 -*-
"""
Created on Wed Jan 17 23:05:49 2024

@author: 12147
"""

import numpy as np
import torch 
import torchbnn as bnn
import pdb
from tqdm import tqdm
import torch.nn as nn
import pdb
#from MMD import RBF, MMDLoss
import pandas as pd

torch.set_num_threads(1)
device = torch.device("cpu")
class BayesianLinear(nn.Module):
    def __init__(self, in_features, out_features):
        super(BayesianLinear, self).__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.weight_mu = nn.Parameter( 0.01* torch.randn(out_features, in_features))
        self.weight_logstd = nn.Parameter(0.01* torch.randn(out_features, out_features))
        self.bias_mu = nn.Parameter(0.01* torch.randn(out_features))
        self.bias_logstd = nn.Parameter(0.01*torch.randn(out_features, out_features))

    def forward(self, x):
        # Sample weights using the reparameterization trick
        rand_shape = torch.zeros(x.shape[0], self.in_features, self.out_features)
        bias_shape = torch.zeros(x.shape[0], self.out_features)
        epsilon_weight = torch.randn_like(x)
        epsilon_bias = torch.randn_like(x)
        sampled_weight = self.weight_mu #+ self.weight_logstd * epsilon_weight
        sampled_bias = self.bias_mu #+ torch.matmul(torch.randn_like(bias_shape), self.bias_logstd)
        #pdb.set_trace()
        z = torch.matmul(x, sampled_weight.transpose(0, 1)) + sampled_bias
        z += torch.matmul(x.unsqueeze(1), torch.matmul(torch.randn_like(rand_shape), self.weight_logstd)).squeeze(1)
        #for i in range(x.shape[0]):
        #    z[i, :] += torch.matmul(x[i, :], torch.matmul(torch.randn_like(rand_shape), self.weight_logstd))
            
        return z#torch.matmul(x, sampled_weight.t()) + x * torch.matmul(epsilon_weight, self.weight_logstd)+ sampled_bias


class BayesianNet(torch.nn.Module):
  def __init__(self, in_feature, H, out_feature):            # 4-100-3
    super(BayesianNet, self).__init__()
    self.batchnorm1 = nn.BatchNorm1d(in_feature)
    self.hid1 = nn.Linear(in_features=in_feature, out_features=H)#bnn.BayesLinear(prior_mu=0, prior_sigma=0.1,
      #in_features=in_feature, out_features=H)
    self.hid2 = nn.Linear(in_features=H, out_features=H)
    self.hid3 = nn.Linear(in_features=H, out_features=H)
    self.hid4 = nn.Linear(in_features=H, out_features=H)
    self.oupt = nn.Linear(in_features=H, out_features=out_feature)#bnn.BayesLinear(prior_mu=0, prior_sigma=0.1,
      #in_features=H, out_features=out_feature)

  def forward(self, x):
    #z = self.batchnorm1(x)
    z = self.hid1(x)  # no softmax: CrossEntropyLoss() 
    z = torch.relu(z)
    res1 = z
    #z = self.batchnorm2(z)
    z = self.hid2(z)
    z = torch.relu(z) + res1
    res2 = z
    #z = self.batchnorm3(z)
    z = self.hid3(z)
    z = torch.relu(z) + res2
    res3 = z
    #z = self.batchnorm4(z)
    z = self.hid4(z)
    z = torch.relu(z) + res3
    z = self.oupt(z)
    return z

import random
# Generate a synthetic dataset
def generate_data():
    import csv

    def read_line(lst):
        result = []
        for i in lst:
            
            result.append(float(i))
            
        return result

    data1 = []

    with open('concrete.csv', mode='r') as file:
        csvFile = csv.reader(file)
        for lines in csvFile:
            data1.append(read_line(lines))

    independent = [0,2,3,4,5,6]
    
        #print(list(line))  # strip() removes leading and trailing whitespace

    data1 = torch.tensor(data1)
    mean = []
    var = []
    for i in range(8):
        mean.append(torch.mean(data1[:, i]))
        var.append(torch.var(data1[:, i]))

    for i in range(8):
        if i != 15:
            
            data1[:, i] = (data1[:, i] - mean[i]) / torch.sqrt(var[i])
            
    yy = torch.zeros(data1.shape[0], 1)
    yy[:, 0] = data1[:, -1]
        
        #X[i, 0]**2 + 2 * X[i, 0] * torch.randn(1)
    #for i in range(batch_sample):
        #print(X[i*batch_num:(i+1)*batch_num, :], torch.ones(batch_num).view(-1, 1))
    #    X[i*batch_num:(i+1)*batch_num, :] = torch.ones(batch_num).view(-1, 1) * (0.2*i+1)
    #    y[i*batch_num:(i+1)*batch_num, :] = X[i*batch_num:(i+1)*batch_num, :]**2 + 2 * X[i*batch_num:(i+1)*batch_num, :] *  torch.randn(X[i*batch_num:(i+1)*batch_num, :].shape)
    #X = torch.ones(num_samples).view(-1, 1)
    #y = X**2 + 0.5 * torch.randn(X.shape)
    loss_data = pd.DataFrame(data = [[float(data1[i, j]) for j in independent] for i in range(data1.shape[0])])
    loss_data.to_csv('concrete_train_x'  + '.csv', header=False, index = False)
    loss_data = pd.DataFrame(data = [[float(data1[i, -1])] for i in range(data1.shape[0])])
    loss_data.to_csv('concrete_train_y'  + '.csv', header=False, index = False)
    #print(torch.mean(y))
    #pdb.set_trace()
    num = data1.shape[0]
    return data1[0:int(num/3*2), independent], yy[0:int(num/3*2), :], data1[int(num/3*2):num, independent], yy[int(num/3*2):num, :]

import random
# Generate a synthetic dataset
def test_error(X_test, y_test, y_test_pred):
    global num_samples, neighborhoods_t, nums_t
    list_test = []
    maximum = 0
    number = 0
    for i in range(X_test.shape[0]):
        if nums_t[i] >= 5:
            list_test.append(i)
            maximum = max(nums_t[i], maximum)
            number += 1
    
    y_test_list = [[0. for i in range(maximum)] for j in range(number)]
    y_test_pred_list = [[0. for i in range(maximum)] for j in range(number)]
    y_test_list = torch.tensor(y_test_list)
    y_test_pred_list = torch.tensor(y_test_pred_list)
    index = 0
    for i in list_test:
        
            
    #rand = random.randint(0, X_test.shape[0]-1)
            neighborhood, num = neighborhoods_t[i], nums_t[i]
            #weights = torch.tensor([1/num for _ in range(num)]).to(device)
            y_test_list[index, 0:nums_t[i]] = y_test[neighborhood, :].transpose(0, 1)[0]
            y_test_pred_list[index, 0:nums_t[i]] = y_test_pred[neighborhood, :].transpose(0, 1)[0]
            index += 1
    #print(torch.mean(y_test_sample), torch.var(y_test_sample))
    #print(torch.mean(y_test_pred_sample), torch.var(y_test_pred_sample))
    #T_list = torch.zeros(num_samples, 14)
    #y = torch.zeros(num_samples, 1)
    #for i in range(num_samples):

    #    for j in range(14):
            
    #        T_list[i, j] = float(mean[j])
            
    #    y[i, 0] = float(mean[-1])
        
        #X[i, 0]**2 + 2 * X[i, 0] * torch.randn(1)
    #for i in range(batch_sample):
        #print(X[i*batch_num:(i+1)*batch_num, :], torch.ones(batch_num).view(-1, 1))
    #    X[i*batch_num:(i+1)*batch_num, :] = torch.ones(batch_num).view(-1, 1) * (0.2*i+1)
    #    y[i*batch_num:(i+1)*batch_num, :] = X[i*batch_num:(i+1)*batch_num, :]**2 + 2 * X[i*batch_num:(i+1)*batch_num, :] *  torch.randn(X[i*batch_num:(i+1)*batch_num, :].shape)
    #X = torch.ones(num_samples).view(-1, 1)
    #y = X**2 + 0.5 * torch.randn(X.shape)
    return y_test_list, y_test_pred_list, list_test


# Instantiate the BNN
input_dim = 6
hidden_dim = 50
output_dim = 1
bnn_model = BayesianNet(input_dim, hidden_dim, output_dim)

# Define the optimizer
optimizer = torch.optim.Adam(bnn_model.parameters(), lr=0.02)

# Training loop


import ot     
def distance(P, Q):
    cost_matrix = ot.dist(P, Q,metric='sqeuclidean')
    return cost_matrix

batch_sample = 10
scale = [ 0.10195824, -0.08923083,  0.00843617, -0.02194843, -0.00312959,
         -0.00638483,
 -0.03299344, -0.03332986, -0.03044914,  0.01757643, -0.03958458, 0.00118903,
 -0.01487187,  0.00302012, -0.09562303]

scale = [ 5.1125035, -1.8629448, -6.844345,   2.0813897, -3.936676 , -5.758478 ]
scale = torch.tensor(scale)
from math import sqrt
def norm(x, y, delta = 0.4):
    global scale
    #scale = scale[0:10]
    scale = scale / torch.sqrt(torch.sum(torch.square(scale)))
    
    #print(scale)
    #print(x-y)
    if torch.sqrt(torch.sum(torch.square((x-y) * scale))) <= delta:
        return True
    
    return False
    
def neighbors(sample, samples, delta):
    
    num = 0
    neighborhood = []
    for i in range(samples.shape[0]):
        
        if norm(sample, samples[i], delta):
            neighborhood.append(i)
            num += 1
        
    return neighborhood, num


    

def w2_decoupled(X, y, y_pred, key='MSE', key2='tr'):
    global neighborhoods, nums, neighborhoods_t, nums_t
    #batch_size = int(y.shape[0] / batch_sample)
    #print(y.shape[0])
    #print(batch_size, y.shape, y_pred.shape)
    #pdb.set_trace()
    #t_size = y.shape[0]
    loss = 0
    #weights = torch.tensor([1/batch_size for _ in range(batch_size)]).to(device)
    if key == 'w2':
        if key2 == 'tr':
        
        #numbers = []
            for i in range(y.shape[0]):
                neighborhood, num = neighborhoods[i], nums[i]#neighbors(X[i], X)
                #numbers.append(num)
                
                #print(num)
                weights = torch.tensor([1/num for _ in range(num)]).to(device)
                #print(y[neighborhood].shape, y_pred[neighborhood].shape)
                loss += ot.emd2(weights, weights, distance(y[neighborhood], y_pred[neighborhood])) * num / sum(nums)
        else:
            for i in range(y.shape[0]):
                neighborhood, num = neighborhoods_t[i], nums_t[i]#neighbors(X[i], X)
                #numbers.append(num)
                
                #print(num)
                weights = torch.tensor([1/num for _ in range(num)]).to(device)
                #print(y[neighborhood].shape, y_pred[neighborhood].shape)
                loss += ot.emd2(weights, weights, distance(y[neighborhood], y_pred[neighborhood])) * num / sum(nums_t)
    elif key == 'W2total':
        num = y.shape[0]
        weights = torch.tensor([1/num for _ in range(num)]).to(device)
        loss += ot.emd2(weights, weights, distance(y, y_pred))
        #loss_data = pd.DataFrame(data = numbers)
        #loss_data.to_csv('numbers'  + '.csv', header=False, index = False)
        #pdb.set_trace()
    elif key == 'MMD':
        for i in range(y.shape[0]):
            if key2 == 'tr':
                neighborhood, num = neighborhoods[i], nums[i]
            #neighborhood, num = neighbors(X[i], X)
            #weights = torch.tensor([1/num for _ in range(num)]).to(device)
            #print(y.shape, y_pred.shape)
                loss += MMDLoss(y[neighborhood], y_pred[neighborhood]) * num / sum(nums)
            else:
                neighborhood, num = neighborhoods_t[i], nums_t[i]
                loss += MMDLoss(y[neighborhood], y_pred[neighborhood]) * num / sum(nums)
                
    elif key == 'MMD_total':
        loss += MMDLoss(y, y_pred)
    elif key == 'MSE':
        criterion = torch.nn.MSELoss(reduction='sum')
        loss += criterion(y, y_pred)
    elif key == 'MSE_local':
        criterion = torch.nn.MSELoss(reduction='sum')
        for i in range(y.shape[0]):
            if key2 == 'tr':
                neighborhood, num = neighborhoods[i], nums[i]
                loss +=criterion(y[neighborhood], y_pred[neighborhood]) #* num / sum(nums)
            else:
                neighborhood, num = neighborhoods_t[i], nums_t[i]
                loss += criterion(y[neighborhood], y_pred[neighborhood]) #* num / sum(nums_t)
        
        loss /= y.shape[0]
    elif key == 'Mean_var':
        criterion = torch.nn.MSELoss(reduction='sum')
        loss += criterion(y, y_pred)
        loss += torch.abs(torch.var(y) - torch.var(y_pred))
    
    
    return loss

def w2_decoupled_1(y, y_pred):
    batch_size = int(y.shape[0])
    y_new = torch.zeros(batch_size, 1)
    y_pred_new = torch.zeros(batch_size, 1)
    for i in range(batch_size):
        y_new[i, 0] = y[i]
        y_pred_new[i, 0] = y_pred[i]
    #print(batch_size, y.shape, y_pred.shape)
    #pdb.set_trace()
    t_size = y.shape[0]
    loss = 0
    weights = torch.tensor([1/batch_size for _ in range(batch_size)]).to(device)
    
    loss += ot.emd2(weights, weights, distance(y_new[:, :], y_pred_new[:, :]))
    
    return loss







def run_experiment(i0, delta, mode = 'r'):
    global neighborhoods, neighborhoods_t, nums, nums_t
    X, y, X_test, y_test = generate_data()
    
    if mode == 'g':
    
        loss_data = pd.DataFrame(data = [[float(X[i, j]) for j in range(X.shape[1])] for i in range(X.shape[0])])
        loss_data.to_csv('HCV_train_data_x'+str(delta) +str(i0)   + '.csv', header=False, index = False)
        
        loss_data = pd.DataFrame(data = [float(y[i]) for i in range(y.shape[0])])
        loss_data.to_csv('HCV_train_data_y'+str(delta) +str(i0)   + '.csv', header=False, index = False)
        
        loss_data = pd.DataFrame(data = [[float(X_test[i, j]) for j in range(X_test.shape[1])] for i in range(X_test.shape[0])])
        loss_data.to_csv('HCV_test_data_x'+str(delta) +str(i0)   + '.csv', header=False, index = False)
        
        loss_data = pd.DataFrame(data = [float(y_test[i]) for i in range(y_test.shape[0])])
        loss_data.to_csv('HCV_test_data_y'+str(delta) +str(i0)   + '.csv', header=False, index = False)
    
    neighborhoods = []
    nums = []
    
    for i in range(y.shape[0]):
        neighborhood, num = neighbors(X[i], X, delta)
        nums.append(num)
        neighborhoods.append(neighborhood)

    neighborhoods_t = []
    nums_t = []
    for i in range(y_test.shape[0]):
        neighborhood, num = neighbors(X_test[i], X_test, 0.2)
        nums_t.append(num)
        neighborhoods_t.append(neighborhood)
    
    num_epochs = 1000
    num_samples = X.shape[0]
    loss_test = []
    loss_train = []
    
    #bnn_model.load_state_dict(torch.load('shortMSE_concrete4_new' +str(delta) +str(i0)  +'501.pkl'))
    # Make predictions with the trained BNN
    
#X, y = generate_test(num_samples)
    for epoch in tqdm(range(num_epochs)):
        
        
        optimizer.zero_grad()
        y_pred = bnn_model(X)
        #pdb.set_trace()
        #loss = criterion(y, y_pred)#w2_decoupled(y, y_pred)#bnn_model.compute_loss(X, y, num_samples)
        loss = w2_decoupled(X, y, y_pred)
        loss.backward()
        optimizer.step()
        loss_train.append(loss.item())
        if (epoch + 1) % 250 == 0:
            print(f'training_loss, Loss: {loss.item()}')
            #X_test, y_test = generate_test(mean, var)
            y_pred_test = bnn_model(X_test)
            test_outcome, pred_outcome, list_test = test_error(X_test, y_test, y_pred_test)
            loss_test.append(w2_decoupled(X_test, y_test, y_pred_test, 'w2', 't').item())
            loss_data = pd.DataFrame(data = [[float(test_outcome[i, j]) for j in range(test_outcome.shape[1])] for i in range(test_outcome.shape[0])])
            loss_data.to_csv('shortMSE_concrete_new_data' +str(delta) +str(i)  + '5015.csv', header=False, index = False)
    
    
            loss_data = pd.DataFrame(data = [[float(pred_outcome[i, j]) for j in range(pred_outcome.shape[1])] for i in range(test_outcome.shape[0])])
            loss_data.to_csv('shortMSE_concrete_new_data_pred' +str(delta) +str(i)  + '5015.csv', header=False, index = False)
    
            print(f'testing_loss, Loss: {loss_test[-1]}')
            print(f"Predicted Mean: {torch.mean(y_pred_test).item()}, Predicted Std: {torch.sqrt(torch.var(y_pred_test)).item()}")
            print(f"truth Mean: {torch.mean(y_test).item()}, truth Std: {torch.sqrt(torch.var(y_test)).item()}")
    
    y_pred_test = bnn_model(X_test)
    test_outcome, pred_outcome, list_test = test_error(X_test, y_test, y_pred_test)
    
    loss_data = pd.DataFrame(data = [float(list_test[i]) for i in range(len(list_test))])
    loss_data.to_csv('shortMSE_concrete_list_04'  +str(delta) +str(i0) + '5015.csv', header=False, index = False)
    
    loss_data = pd.DataFrame(data = [float(loss_train[i]) for i in range(len(loss_train))])
    loss_data.to_csv('shortMSE_concrete_list_train_loss' +str(delta) +str(i0)  + '5015.csv', header=False, index = False)
    
    loss_data = pd.DataFrame(data = [float(loss_test[i]) for i in range(len(loss_test))])
    loss_data.to_csv('shortMSE_concrete_list_test_loss'+str(delta) +str(i0)   + '5015.csv', header=False, index = False)
    
    ##############
    #pdb.set_trace()
    
    y_pred = bnn_model(X)
    y_pred_test = bnn_model(X_test)
    
    
    
    loss_data = pd.DataFrame(data = [float(y_test[i]) for i in range(y_test.shape[0])])
    loss_data.to_csv('shorttest_MSE_concrete_new' +str(delta) +str(i0)  + '5015.csv', header=False, index = False)
    
    loss_data = pd.DataFrame(data = [float(y_pred_test[i]) for i in range(y_pred_test.shape[0])])
    loss_data.to_csv('shorttest_MSE_concrete_new_pred'+str(delta) +str(i0)  + '5015.csv', header=False, index = False)
    
    #test_outcome, pred_outcome = test_error(X_test, y_test, y_pred_test)
    
    loss_data = pd.DataFrame(data = [[float(test_outcome[i, j]) for j in range(test_outcome.shape[1])] for i in range(test_outcome.shape[0])])
    loss_data.to_csv('shorttest_MSE_concrete_new_data'+str(delta) +str(i0)   + '5015.csv', header=False, index = False)
    
    
    loss_data = pd.DataFrame(data = [[float(pred_outcome[i, j]) for j in range(pred_outcome.shape[1])] for i in range(pred_outcome.shape[0])])
    loss_data.to_csv('shorttest_MSE_concrete_new_data_pred' +str(delta) +str(i0)  + '5015.csv', header=False, index = False)
    
    
    #loss_data = pd.DataFrame(data = [float(y[i]) for i in range(y.shape[0])])
    #loss_data.to_csv('truth_data_nonlinear'  + '.csv', header=False, index = False)
    
    #loss_data = pd.DataFrame(data = [float(y_pred[i]) for i in range(y.shape[0])])
    #loss_data.to_csv('predict_data_nonlinear'  + '.csv', header=False, index = False)
    
    #torch.save(bnn_model.state_dict(), 'shortMSE_concrete4_new' +str(delta) +str(i0)  +'501.pkl')
    print(f"Predicted Mean: {torch.mean(y_pred).item()}, Predicted Std: {torch.sqrt(torch.var(y_pred)).item()}")
    print(f"truth Mean: {torch.mean(y).item()}, truth Std: {torch.sqrt(torch.var(y)).item()}")

for i in range(5):
    delta = 0.2
    run_experiment(i, delta, 'g')
    