function plot_concrete
data1 = csvread('shorttest_w2_concrete_new_data0.053505.csv');
data2 = csvread('shorttest_w2_concrete_new_data_pred0.053505.csv');
[m, n] = size(data1);
%disp(m)
%disp(n)
%disp(n)
%disp(n)

means = zeros(m, 1);
for i=1:m
    for j=1:n
        if data1(i, j) == 0
            record = j-1;
            break;
        end
    end
    means(i) = mean(data1(i, 1:record));
end
means_sort = sort(means);

index_list = zeros(10, 1);
for j0=1:10
    for i=1:m
        if means(i) == means_sort(floor(n/10)*j0+1)
            index_list(j0) = j0;
            %disp(means(i))
        end
    end
end

%index_list = [1, 6, 11, 16, 18, 22, 23, 24, 25, 28, 33, 37, 42];
index_list = [1,  11,  18, 22, 24, 25, 28, 33, 37, 42];
index_list = [1,  16,  21,28, 34, 45, 61, 73, 84, 90];
    function scattering(i)
        data_sample = zeros(10, 1);
        summ = 0;
        for s=1:10
            record = 0;
            for j1=1:n
                
                if data1(index_list(s), j1) == 0
                    
                    record = j1-1;
                    break;
                end
                if and(j1 == n, data1(index_list(s), j1) ~= 0)
                    record = j1;
                end
            end
            summ = summ + record;
            if s == 1
                data_sample(s) = record;
            else
                data_sample(s) = data_sample(s-1) + record;
            end
        end
        %disp(data_sample)
        x = zeros(summ, 1);
        data_truth = zeros(summ, 1);
        data_pred = zeros(summ, 1);
        for s=1:10
            
            if s == 1
                x(1:data_sample(s)) = s;
                data_truth(1:data_sample(s)) = data1(index_list(s), 1:data_sample(s));
                data_pred(1:data_sample(s)) = data2(index_list(s), 1:data_sample(s));
            else
                x(data_sample(s-1)+1:data_sample(s)) = s;
                data_truth(data_sample(s-1)+1:data_sample(s)) = data1(index_list(s), 1:data_sample(s)-data_sample(s-1));
                data_pred(data_sample(s-1)+1:data_sample(s)) = data2(index_list(s), 1:data_sample(s)-data_sample(s-1));
            end
        end
        %disp(x)
        scatter(x, data_truth, 'color', 'b', 'DisplayName', 'ground truth {\boldmath{$y$}}({\boldmath{$x$}};\omega)$')
        hold on;
        scatter(x, data_pred, 'color', 'r', 'marker', '*', 'DisplayName', 'predicted \boldmath{$\hat{y}$}(\boldmath{$x$};\omega)$')
        legend('ground truth {{$y$}}$(${\boldmath{$x$}}; $\omega)$', 'predicted {{$\hat{y}$}}$(${\boldmath{$x$}}$;\hat{\omega})$', 'Location', 'north', 'interpreter', 'latex', 'Box', 'off')
        set(gca, 'fontsize', 16)
        xlabel('sample index', 'Interpreter', 'latex')
        ylabel('concrete compressive strength', 'Interpreter', 'latex')
        xticks([1,2,3,4,5,6,7,8,9,10]);   % Set ticks at 0, π/2, π, 3π/2, and 2π
        xticklabels({[index_list(1), index_list(2),index_list(3),index_list(4),index_list(5),index_list(6),index_list(7),index_list(8),index_list(9),index_list(10)]}); 
        xlim([1, 10])
        title('(a) concrete compressive strength distribution', 'Interpreter', 'latex')
    end

        %x = zeros(record, 1);
            
        %disp(mean(data1(i, 1:record)))
        %disp(sqrt(var(data1(i, 1:record))))
        hold on;
        %disp(x(1:100))
        %disp(data1)
        
        %disp(mean(data2(i, 1:record)))
        %disp(sqrt(var(data2(i, 1:record))))

scattering(3)
ylim([10, 90])
end